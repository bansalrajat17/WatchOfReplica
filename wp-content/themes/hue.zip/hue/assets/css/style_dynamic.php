<?php

do_action('hue_mikado_style_dynamic');