<?php
hue_mikado_get_footer();
?>