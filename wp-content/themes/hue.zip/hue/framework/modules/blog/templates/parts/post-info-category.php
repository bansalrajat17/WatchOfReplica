<div class="mkd-post-info-category mkd-post-info-item">
	<?php foreach(get_the_category() as $category){  echo hue_mikado_category_color_name($category);} ?>
</div>