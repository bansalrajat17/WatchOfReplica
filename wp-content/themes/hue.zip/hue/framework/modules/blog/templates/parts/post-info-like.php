<div class="mkd-blog-like mkd-post-info-item">
    <?php if(function_exists('hue_mikado_get_like')) {
		hue_mikado_get_like();
	} ?>
</div>