<div class="mkd-blog-share mkd-post-info-item">
    <?php echo hue_mikado_get_social_share_html(); ?>
</div>