<div class="mkd-portfolio-info-item">
	<h4 class="mkd-portfolio-item-title"><?php the_title(); ?></h4>

	<?php hue_mikado_portfolio_get_info_part('categories'); ?>

	<div class="mkd-portfolio-item-content">
		<?php the_content(); ?>
	</div>
</div>