<?php

if(hue_mikado_contact_form_7_installed()) {
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/options-map/map.php';
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/custom-styles/contact-form.php';
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/contact-form-7-config.php';
	include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/contactform7/widgets/contact-form-7.php';
}