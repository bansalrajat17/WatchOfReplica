<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/comparison-pricing-tables/cpt-holder.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/comparison-pricing-tables/cpt-table.php';