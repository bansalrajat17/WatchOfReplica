<div class="mkd-cards-holder">
    <div class="mkd-cards-header cards">

    </div>
    <div class="mkd-card-panes">
        <?php echo do_shortcode($content); ?>
    </div>
</div>