<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/cards-slider/cards-slider.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/cards-slider/cards-slider-item.php';