<div class="mkd-process-slider-holder <?php echo esc_attr($light_nav)?>">
    <div class="mkd-process-slider-holder-inner">
        <div class="mkd-process-slider">
            <?php echo do_shortcode($content); ?>
        </div>
    </div>
</div>