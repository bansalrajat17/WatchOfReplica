<?php

include_once get_template_directory().'/framework/modules/shortcodes/tab-slider/tab-slider.php';
include_once get_template_directory().'/framework/modules/shortcodes/tab-slider/tab-slider-item.php';