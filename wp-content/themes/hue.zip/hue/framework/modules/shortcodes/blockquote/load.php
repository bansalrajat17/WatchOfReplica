<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blockquote/options-map/map.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blockquote/blockquote.php';
include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/blockquote/custom-styles/blockquote.php';