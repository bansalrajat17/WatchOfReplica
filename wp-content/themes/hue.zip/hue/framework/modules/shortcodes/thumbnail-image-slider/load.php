<?php

include_once MIKADO_FRAMEWORK_MODULES_ROOT_DIR.'/shortcodes/thumbnail-image-slider/thumbnail-image-slider.php';