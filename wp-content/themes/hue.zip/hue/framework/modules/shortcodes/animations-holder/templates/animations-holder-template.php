<div <?php hue_mikado_class_attribute($class); ?> <?php echo hue_mikado_get_inline_attrs($data); ?>>
	<div <?php hue_mikado_inline_style($style); ?>>
		<?php echo do_shortcode($content); ?>
	</div>

</div>