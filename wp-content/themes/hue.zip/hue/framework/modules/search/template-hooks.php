<?php

//Get search HTML
add_action('hue_mikado_before_page_header', 'hue_mikado_get_search', 9);