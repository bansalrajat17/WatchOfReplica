<div class="mkd-grid-row mkd-footer-bottom-one-col">
	<div class="mkd-grid-col-12">
		<?php if(is_active_sidebar('footer_text')) :
			dynamic_sidebar('footer_text');
		endif; ?>
	</div>
</div>