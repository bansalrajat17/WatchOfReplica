<div class="mkd-grid-row">
	<div class="mkd-grid-col-12">
		<?php if(is_active_sidebar('footer_column_1')) :
			dynamic_sidebar('footer_column_1');
		endif; ?>
	</div>
</div>