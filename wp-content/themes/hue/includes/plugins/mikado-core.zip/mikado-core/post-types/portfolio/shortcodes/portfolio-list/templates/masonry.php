<article class="mkd-portfolio-item<?php echo esc_attr($space_btw_items) ?> <?php echo esc_attr($article_masonry_size) ?> <?php echo esc_attr($categories) ?>">
    <div class="mkd-portfolio-masonry-item">
        <a class="mkd-portfolio-link" href="<?php echo esc_url($item_link); ?>" target="<?php echo esc_attr($item_target); ?>"></a>

        <div class="mkd-item-image-holder">
            <?php
            echo get_the_post_thumbnail(get_the_ID(), $thumb_size);
            ?>
        </div>
        <div class="mkd-ptf-item-text-overlay">
            <span class="mkd-ptf-item-overlay-bg <?php echo esc_attr($gradient_style) ?>"></span>
            <div class="mkd-ptf-item-text-overlay-inner">
                <div class="mkd-ptf-item-text-holder">

                    <?php if($params['portfolio_hover_type'] == 'standard') : ?>
                        <?php if($is_external){ ?>
                            <a class="mkd-ptf-portfolio-overlay-icon" href="<?php echo esc_url($item_link); ?>" target="<?php echo esc_attr($item_target); ?>">
                        <?php }else{ ?>
                            <a class="mkd-ptf-portfolio-overlay-icon" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" data-rel="prettyPhoto[portfolio-standard]">
                        <?php }?>
                            <?php echo hue_mikado_icon_collections()->renderIcon('icon_plus', 'font_elegant'); ?>
                        </a>
                    <?php endif; ?>

                    <?php if($params['portfolio_hover_type'] == 'gradient') : ?>
                        <?php if($is_external){ ?>
                            <a class="mkd-ptf-portfolio-overlay-icon mkd-eye" href="<?php echo esc_url($item_link); ?>" target="<?php echo esc_attr($item_target); ?>">
                        <?php }else{ ?>
                            <a class="mkd-ptf-portfolio-overlay-icon mkd-eye" href="<?php echo esc_url(wp_get_attachment_url(get_post_thumbnail_id())); ?>" data-rel="prettyPhoto[portfolio-standard]">
                        <?php }?>
                            <?php echo hue_mikado_icon_collections()->renderIcon('lnr-eye', 'linear_icons'); ?>
                        </a>
                    <?php endif; ?>

                    <<?php echo esc_attr($title_tag) ?> class="mkd-ptf-item-title">
                    <a href="<?php echo esc_url($item_link) ?>" target="<?php echo esc_attr($item_target); ?>">
                        <?php echo esc_html(get_the_title()); ?>
                    </a>
                </<?php echo esc_attr($title_tag) ?>>
                <?php if($show_excerpt === 'yes') : ?>
                        <p><?php echo esc_html($caller->itemExcerpt($excerpt_length)); ?></p>
                <?php endif; ?>

                <?php if($show_category === 'yes') : ?>
                    <?php if(!empty($category_html)) : ?>
                        <?php print $category_html; ?>
                    <?php endif; ?>
                <?php endif; ?>

            </div>
        </div>
    </div>
    </div>
</article>
