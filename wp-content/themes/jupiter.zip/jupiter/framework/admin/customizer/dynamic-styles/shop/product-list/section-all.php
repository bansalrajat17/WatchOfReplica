<?php
/**
 * Add dynamic styles here.
 *
 * @package Jupiter
 * @subpackage MK_Customizer
 * @since 5.9.4
 */

$css = '';

return $css;
