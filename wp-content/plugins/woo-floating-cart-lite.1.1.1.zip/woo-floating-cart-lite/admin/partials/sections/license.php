<?php
echo $this->core->license()->form();