<a class="xt-refresh-link" href="<?php echo $this->get_section_url('shop', array('nocache'=>'1'));?>">
	<span class="dashicons dashicons-image-rotate"></span> Refresh
</a>
<h3>Products you might like</h3>
			
<?php echo $this->get_shop_products(); ?>