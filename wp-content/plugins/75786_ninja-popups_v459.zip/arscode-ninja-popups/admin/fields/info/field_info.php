<?php

class SNP_NHP_Options_info extends SNP_NHP_Options
{
	public function __construct($field = array(), $value ='', $parent)
	{
		parent::__construct($parent->sections, $parent->args, $parent->extra_tabs);

		$this->field = $field;
		$this->value = $value;
	}

	public function render()
	{
		$class = (isset($this->field['class']))?' '.$this->field['class']:'';

		echo '<div>'.$this->field['desc'].'</div>';	
	}
}