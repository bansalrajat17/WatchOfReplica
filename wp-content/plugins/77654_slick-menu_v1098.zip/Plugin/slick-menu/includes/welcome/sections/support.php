
<a target="_blank" href="http://xt.ticksy.com">
	<span class="dashicons dashicons-sos"></span> Visit our online support center
</a>