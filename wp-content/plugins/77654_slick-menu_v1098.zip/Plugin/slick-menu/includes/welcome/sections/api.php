<?php

$data = slick_menu_remote_get_data('js-api');

echo $data;	