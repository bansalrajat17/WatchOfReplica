<?php
echo $this->parent->license()->form();