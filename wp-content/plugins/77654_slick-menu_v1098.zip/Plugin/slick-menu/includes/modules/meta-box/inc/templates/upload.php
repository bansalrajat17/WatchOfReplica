<script id="tmpl-sm-rwmb-upload-area" type="text/html">
  <div class="sm-rwmb-upload-inside">
    <h3>{{{ i18nRwmbMedia.uploadInstructions }}}</h3>
    <p> or</p>
    <p><a href="#" class="sm-rwmb-browse-button button button-hero" id="{{{ _.uniqueId( 'sm-rwmb-upload-browser-') }}}">{{{ i18nRwmbMedia.select }}}</a></p>
  </div>
</script>
