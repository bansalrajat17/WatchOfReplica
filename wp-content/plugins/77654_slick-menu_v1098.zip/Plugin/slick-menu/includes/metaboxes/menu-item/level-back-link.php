<?php

return $this->get_menu_items_fields($id);

