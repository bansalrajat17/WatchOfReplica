<?php

return $this->get_menu_items_fields(
	$id, 
	array(
		"{$prefix}content-bg",
		"{$prefix}content-shadow"
	)
);
