<?php

return array(

	SM_RWMB_EXTEND_Groups::hamburgerTrigger(array(
	    'id' 		=> "{$prefix}hamburger-top-left",
	    'toggle'	=> false,
		'std' 		=> '',
		'tab'  => 'top-left'
	)),
	
	SM_RWMB_EXTEND_Groups::hamburgerTrigger(array(
	    'id' 		=> "{$prefix}hamburger-top-right",
	    'toggle'	=> false,
		'std' 		=> '',
		'tab'  => 'top-right'
	)),
);